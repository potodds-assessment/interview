package interview;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

public class RWLock implements ReadWriteLock {

	@Override
	public Lock readLock() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Lock writeLock() {
		// TODO Auto-generated method stub
		return null;
	}

}
